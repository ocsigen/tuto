
CREATE TABLE users ( 
       login text NOT NULL,
       password text NOT NULL
);

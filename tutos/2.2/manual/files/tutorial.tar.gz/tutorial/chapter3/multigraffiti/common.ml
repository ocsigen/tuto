type messages = (string * int * (int * int) * (int * int)) deriving (Json)

let width = 700
let height = 400

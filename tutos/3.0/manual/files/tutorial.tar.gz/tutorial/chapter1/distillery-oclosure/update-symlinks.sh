#!/bin/sh

ln -s ../../static .

